//db credentials
db owner: ameri_admin
db owner password: admin@ameri123



//admin credentials
email: admin@ameri.com
password: admin@1234